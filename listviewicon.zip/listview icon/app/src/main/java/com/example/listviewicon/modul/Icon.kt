package com.example.listviewicon.modul

class Icon {
    var name: String = ""
    var detail: String = ""
    var poster: Int = 0
}