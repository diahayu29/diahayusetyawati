package com.example.listviewicon.modul

import com.example.listviewicon.R


object Icon_Data {
        private val iconName = arrayOf(
            "Ruby",
            "Rails",
            "Python",
            "Java Script",
            "PHP"
        )

    private val detail = arrayOf(
        "Ruby adalah bahasa pemrograman dinamis berbasis skrip yang berorientasi objek.",
        "Rails merupakan framework yang dipakai untuk membuat suatu aplikasi web yang dibuat dengan bahasa pemrograman Ruby.",
        "Python adalah bahasa pemrograman interpretatif multiguna dengan filosofi perancangan yang berfokus pada tingkat keterbacaan kode",
        "Javascript adalah bahasa pemrograman yang wajib kamu pelajari jika ingin mendalami dunia web development.",
        "PHP adalah singkatan dari PHP Hypertext Prepocessor, yaitu bahasa pemrograman yang digunakan secara luas untuk penanganan pembuatan dan pengembangan sebuah situs web dan bisa digunakan bersamaan dengan HTML. "
    )

    private val iconPoster = intArrayOf(
        R.drawable.ruby,
        R.drawable.rails,
        R.drawable.phyton,
        R.drawable.js,
        R.drawable.php
    )

    val listicon: ArrayList<Icon>
        get() {
            val list = arrayListOf<Icon>()
            for (position in iconName.indices) {
                val icon = Icon()
                icon.name = iconName[position]
                icon.detail = detail[position]
                icon.poster = iconPoster[position]
                list.add(icon)
            }
            return list
        }
}